import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('https://cms.anhtester.com/login')

WebUI.setText(findTestObject('Brand/input_email'), email)

WebUI.setText(findTestObject('Brand/input_password'), password)

WebUI.click(findTestObject('Brand/check'))

WebUI.click(findTestObject('Brand/button_Login'))

WebUI.delay(3)

WebUI.click(findTestObject('Brand/menu'))

WebUI.click(findTestObject('Brand/span_Products'))

WebUI.click(findTestObject('Brand/span_Brand'))

WebUI.setText(findTestObject('Brand/input_name'), name)

WebUI.setText(findTestObject('Brand/input_meta_title'), meta_title)

WebUI.setText(findTestObject('Brand/textarea_description'), meta_description)

WebUI.click(findTestObject('Brand/button_Save'))

if (name == '') {
    String nameMessage = WebUI.executeJavaScript('return document.querySelector("input[name=\'name\']").validationMessage;', 
        null)

    WebUI.verifyMatch(nameMessage, 'Please fill out this field.', false)
}

WebUI.delay(3)

WebUI.setText(findTestObject('Brand/input_Brands_search'), search)

WebUI.sendKeys(findTestObject('Brand/input_Brands_search'), Keys.chord(Keys.ENTER))

WebUI.delay(5)

WebUI.closeBrowser()

