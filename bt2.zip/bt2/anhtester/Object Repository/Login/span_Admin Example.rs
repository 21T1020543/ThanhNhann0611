<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Admin Example</name>
   <tag></tag>
   <elementGuidId>36712538-1e96-443d-8311-c294f7604f79</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.d-block.fw-500</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Vietnamese'])[1]/following::span[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Admin Example staff&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>b0b95c3f-2473-4f6c-b615-f3f2184f9271</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>d-block fw-500</value>
      <webElementGuid>48a2ef40-949b-46df-a7a3-8a786b18578f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Admin Example</value>
      <webElementGuid>2153ba17-0e46-4acb-a674-18a4b9bbfcfd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;side-menu-closed&quot;]/div[@class=&quot;aiz-main-wrapper&quot;]/div[@class=&quot;aiz-content-wrapper&quot;]/div[@class=&quot;aiz-topbar px-15px px-lg-25px d-flex align-items-stretch justify-content-between&quot;]/div[@class=&quot;d-flex justify-content-between align-items-stretch flex-grow-xl-1&quot;]/div[@class=&quot;d-flex justify-content-around align-items-center align-items-stretch&quot;]/div[@class=&quot;aiz-topbar-item ml-2&quot;]/div[@class=&quot;align-items-stretch d-flex dropdown&quot;]/a[@class=&quot;dropdown-toggle no-arrow text-dark&quot;]/span[@class=&quot;d-flex align-items-center&quot;]/span[@class=&quot;d-none d-md-block&quot;]/span[@class=&quot;d-block fw-500&quot;]</value>
      <webElementGuid>a109a236-e084-4309-bedc-803bd95410f3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Vietnamese'])[1]/following::span[4]</value>
      <webElementGuid>19e4579e-5106-4d2f-9f1b-bf53fe84b307</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='English'])[1]/following::span[5]</value>
      <webElementGuid>f99efd8d-b98d-4615-9303-df1a87f607ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='staff'])[1]/preceding::span[1]</value>
      <webElementGuid>5e1ca04f-8fb6-41fe-a18e-3bbfcbb85ac4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Profile'])[1]/preceding::span[2]</value>
      <webElementGuid>6c6e1464-7e34-41b2-9e6c-82cc8f44c3f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Admin Example']/parent::*</value>
      <webElementGuid>6579ea30-7166-4147-8945-eb390a3159da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[2]/span</value>
      <webElementGuid>e4ad7bee-25e6-44e8-b3a4-4a6436ffc14e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Admin Example' or . = 'Admin Example')]</value>
      <webElementGuid>60482091-2e60-4cb7-a700-00ab1d46d1d1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
