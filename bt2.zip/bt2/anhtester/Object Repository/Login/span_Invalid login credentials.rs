<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Invalid login credentials</name>
   <tag></tag>
   <elementGuidId>72f59a08-9d1b-4cd2-a5e5-03346c8c7f22</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.aiz-notify.alert.alert-danger > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Invalid login credentials&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>1e74a91d-8441-4b73-a406-adbc79f661d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-notify</name>
      <type>Main</type>
      <value>message</value>
      <webElementGuid>270768d1-d33e-408c-8e5a-5a94a8acfc0c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Invalid login credentials</value>
      <webElementGuid>2bec0887-ca8b-47ed-bef7-18d942765bc4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;side-menu-closed&quot;]/div[@class=&quot;aiz-notify alert alert-danger&quot;]/span[1]</value>
      <webElementGuid>00558657-2d47-433e-9d8c-947870b88650</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/following::span[1]</value>
      <webElementGuid>ee93e5b1-54af-42a6-af4f-3e5f652b97a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Forgot password ?'])[1]/following::span[1]</value>
      <webElementGuid>e6918bf7-015f-4310-8b67-6b8a4263ae2c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Invalid login credentials']/parent::*</value>
      <webElementGuid>1933132f-f22b-412f-abc2-d6dda964f674</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/span</value>
      <webElementGuid>fcda216e-041d-47c3-a51d-eca2388177e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Invalid login credentials' or . = 'Invalid login credentials')]</value>
      <webElementGuid>70d010a1-1e85-409d-a9dc-44e5bf05a425</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
