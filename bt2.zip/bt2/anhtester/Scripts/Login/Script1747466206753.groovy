import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('https://cms.anhtester.com/login')

WebUI.maximizeWindow()

// Nhập username (có thể trống từ test data)
WebUI.setText(findTestObject('Page_Active eCommerce CMS  Anh Tester Demo/input_Welcome to Active eCommerce CMS_email'), 
    username)

// Nhập password (có thể trống từ test data)
WebUI.setText(findTestObject('Page_Active eCommerce CMS  Anh Tester Demo/input_Welcome to Active eCommerce CMS_password'), 
    password)

// Click nút "Remember Me" nếu cần
WebUI.click(findTestObject('Login/check'))

// Click Login
WebUI.click(findTestObject('Page_Active eCommerce CMS  Anh Tester Demo/button_Login'))

WebUI.delay(2)

// Xử lý kiểm tra theo điều kiện
if (username == '') {
    String validationMessage = WebUI.executeJavaScript('return document.querySelector(\'input[name="email"]\').validationMessage;', 
        null)

    WebUI.comment('Username validation: ' + validationMessage)

    assert validationMessage == 'Please fill out this field.' // Nếu cả 2 trường đều có dữ liệu, kiểm tra theo thông báo mong đợi
} else if (password == '') {
    String validationMessage = WebUI.executeJavaScript('return document.querySelector(\'input[name="password"]\').validationMessage;', 
        null)

    WebUI.comment('Password validation: ' + validationMessage)

    assert validationMessage == 'Please fill out this field.'
} else {
    WebUI.delay(2)

    WebUI.verifyTextPresent(expected_msg, false)
}

WebUI.closeBrowser()

